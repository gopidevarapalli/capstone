import React, { useEffect, useState } from 'react';
import './styles.css'
import { useDispatch, useSelector } from 'react-redux';
import { NavLink, useNavigate } from 'react-router-dom';
import { loginAction, updateProductSearch } from '../redux/actions';
import { faHome, faInfoCircle, faShoppingCart, faSignOut, faUser, faUsers } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const Header = () => {
  const [showNavOptions, setShowNavOptions] = useState(false);
  const setActiveLink = ({ isActive }) => isActive ? "nav-link active text-warning" : "nav-link";
  const cart = useSelector(state => state.cart);
  const login = useSelector(state => state.login);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const searchProduct = (value) => {
    dispatch(updateProductSearch(value))
  }
  const logout = () => {
    localStorage.removeItem('user');
    dispatch(loginAction(null));
    navigate(`/`);
  }

  useEffect(() => {
    if (!login?.data) {
      navigate(`/`);
    }
  }, [])

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light">
      <div className="container-fluid">
        <NavLink className="navbar-brand d-flex align-items-center" to="/">
          <img src="/images/hcllogo.png" alt="Logo" width={200} className="d-inline-block align-top" />
          <h3 className='center ms-3'>Shopify</h3>
        </NavLink>
        <div className="search-box">
          <input type='search' placeholder='Search product...' className="form-control" onChange={(e) => searchProduct(e?.target?.value)} />
        </div>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <NavLink className={({ isActive }) => setActiveLink({ isActive })} to="/" end> <FontAwesomeIcon icon={faHome} /> Home</NavLink>
            </li>
            {login?.data?.role === "Manager" &&
              <li className="nav-item">
                <NavLink className={({ isActive }) => setActiveLink({ isActive })} to="/users"><FontAwesomeIcon icon={faUsers} /> Users</NavLink>
              </li>}
            <li className="nav-item">
              <NavLink className={({ isActive }) => setActiveLink({ isActive })} to="/cart"><FontAwesomeIcon icon={faShoppingCart} />  Cart {cart?.data?.length || ''}</NavLink>
            </li>
            <li className="nav-item" style={{ position: 'relative' }}>
              <NavLink className="nav-link avatar" to="#" onClick={() => setShowNavOptions(!showNavOptions)}>
              <FontAwesomeIcon icon={faUser} />  {login?.data?.name}
              </NavLink>
              {showNavOptions && (
                <div className="nav-options">
                  <ul>
                    <li onClick={() => navigate("/orders")}>My Orders</li>
                    <li onClick={logout}>Logout</li>
                  </ul>
                </div>
              )}
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Header;
