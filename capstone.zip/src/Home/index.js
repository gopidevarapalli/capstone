import React, { useEffect } from "react";
import Users from "../Users";
import Products from "../Products";
import { useDispatch, useSelector } from "react-redux";
import { fetchProdutsSuccess, fetchproductsRequest } from "../redux/actions";
import axios from "axios";
import { apiURL } from "../Config";
import Header from "../Header";
import Footer from "../Footer";

const Home = () => {
    const login = useSelector(state => state.login);
    const products = useSelector(state => state?.products);
    const dispatch = useDispatch();
    useEffect(()=>{
        console.log('login=', login)
        if(!products?.isDataLoaded) {
            dispatch(fetchproductsRequest())
            axios.get(`${apiURL}/products`)
            .then((res)=>{
                dispatch(fetchProdutsSuccess(res.data));
            });
        }
    }, [])

    return (
        <div>
            <Header />
            <h1 className="text text-center text-warning">Welcome {login?.data?.name} ({login?.data?.sapId})</h1>
            <hr />
            <Products />
            <Footer />
        </div>
    )
}

export default Home;