import { BUY_COMPUTER, BUY_MOBILE, FETCH_PRODUCTS_FAILURE, FETCH_PRODUCTS_FILTER, FETCH_PRODUCTS_REQUEST, FETCH_PRODUCTS_SEARCH, FETCH_PRODUCTS_SUCCESS, FETCH_USERS_FAILURE, FETCH_USERS_REQUEST, FETCH_USERS_SUCCESS, LOGIN, UPDATE_CART } from "../actionTypes"

export const BuyComputerAction = () => {
    return {
        type: BUY_COMPUTER
    }
}

export const BuyMobileAction = () => {
    return {
        type: BUY_MOBILE
    }
}

export const loginAction = (data) => {
    return {
        type: LOGIN,
        data
    }
}

export const fetchproductsRequest = () => {
    return {
        type:FETCH_PRODUCTS_REQUEST
    }
}
export const fetchProdutsSuccess = (products) => {
    return {
        type:FETCH_PRODUCTS_SUCCESS,
        data:products
    }
}
export const updateProductSearch = (searchWord) => {
    return {
        type: FETCH_PRODUCTS_SEARCH,
        searchTerm: searchWord
    }
}
export const updateProductFilter = (filter) => {
    return {
        type: FETCH_PRODUCTS_FILTER,
        filter
    }
}
export const fetchProductsFailure = (error) => {
    return {
        type:FETCH_PRODUCTS_FAILURE,
        data:error
    }
}

export const fetchUsersRequest = () => {
    console.log('user data loading');
    return {
        type:FETCH_USERS_REQUEST
    }
}
export const fetchUsersSuccess = (users) => {
    return {
        type:FETCH_USERS_SUCCESS,
        data:users
    }
}
export const fetchUsersFailure = (error) => {
    return {
        type:FETCH_USERS_FAILURE,
        data:error
    }
}
export const updateCart = (data) => {
    return {
        type: UPDATE_CART,
        data: data
    }
}

export const CLEAR_CART = () => {
    return {
        type: UPDATE_CART,
        data: []
    }
}