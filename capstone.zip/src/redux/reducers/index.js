import { BUY_COMPUTER, BUY_MOBILE, CLEAR_CART, FETCH_PRODUCTS_FAILURE, FETCH_PRODUCTS_FILTER, FETCH_PRODUCTS_REQUEST, FETCH_PRODUCTS_SEARCH, FETCH_PRODUCTS_SUCCESS, FETCH_USERS_FAILURE, FETCH_USERS_REQUEST, FETCH_USERS_SUCCESS, LOGIN, UPDATE_CART } from "../actionTypes"

const initialState = {
    loading:false,
    products:[ ],
    numOfComputers: 9,
    numOfMobiles: 9,
    error:''
}
const productsInitialState = {
    isDataLoaded: false,
    loading: false,
    data: [],
    searchTerm:'',
    filter: {
        enable: false,
        orderBy: '',
        rating: 0
    }

}
const usersInitialState = {
    isDataLoaded: false,
    loading: false,
    data: [],
}
const cartInitialState = {
    isDataLoaded: false,
    loading: false,
    data: [],
}

const loginInitialState = {
    data: null
}
export const reducer = (state=initialState,action) =>{
    switch(action.type){
      case BUY_COMPUTER:
          return {...state, numOfComputers: state.numOfComputers - 1}
      case BUY_MOBILE:
          return {...state, numOfMobiles: state.numOfMobiles - 1}
      default:
          return state
    }
  }

  export const productsReducer = (state = productsInitialState,action) => {
    switch(action.type) {
    case FETCH_PRODUCTS_REQUEST:
        return {...state, loading:true}
    case FETCH_PRODUCTS_SUCCESS:
        return {...state ,loading:false, data:action.data, error:'', isDataLoaded: true}
    case FETCH_PRODUCTS_SEARCH:
            return {...state, searchTerm: action?.searchTerm}
    case FETCH_PRODUCTS_FILTER:
            return {...state, filter: action?.filter}
    case FETCH_PRODUCTS_FAILURE:
        return {...state,loading:false, data:[], error:action.data}
    default:
            return state
    }
  }


  export const usersReducer = (state = usersInitialState,action) => {
    switch(action.type) {
    case FETCH_USERS_REQUEST:
        return {...state, loading:true}
    case FETCH_USERS_SUCCESS:
          console.log('success USERS', action.data)
        return {...state ,loading:false, data:action.data, error:'', isDataLoaded: true}
    case FETCH_USERS_FAILURE:
        return {...state,loading:false, data:[], error:action.data}
    default:
            return state
    }
  }

  export const loginReducer = (state = loginInitialState, action) => {
    switch(action.type) {
        case LOGIN:
            return {...state, data: action?.data}
        default:
            return state

  }
}
  export const cartReducer = (state = cartInitialState,action) => {
    switch(action.type) {
    case UPDATE_CART:
          console.log('success CART', action.data)
        return {...state ,loading:false, data:action.data, error:'', isDataLoaded: true}
    case CLEAR_CART:
        return {...state,loading:false, data:[], error:action.data}
    default:
            return state
    }
  }