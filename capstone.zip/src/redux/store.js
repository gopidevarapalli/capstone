import { applyMiddleware, combineReducers, createStore } from "redux";
import {thunk} from 'redux-thunk';
import { cartReducer, loginReducer, productsReducer, reducer, usersReducer } from "./reducers";


const reducers = combineReducers({
    products: productsReducer,
    users: usersReducer,
    cart: cartReducer,
    login: loginReducer,
    all: reducer,
})
export const store = createStore(reducers, applyMiddleware(thunk));