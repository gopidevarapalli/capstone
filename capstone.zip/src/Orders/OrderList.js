import moment from 'moment';
import React from 'react';

const OrderList = ({ order }) => {


  return (
    <div className="container mt-5">
      <div className="row">
        <div className="col">
          <div className="card mb-4">
            <div className="card-header d-flex justify-content-between align-items-center">
              <span>Order ID: {order.id}</span>
              <span>Order Date: {moment(order.orderDate).format('DD MMMM YYYY')}</span>
            </div>
            <div className="card-body">
              <ul className="list-group">
                {order.selectedItems.map(item => (
                  <li key={item.id} className="list-group-item">
                    <div className="row">
                      <div className="col-md-3">
                        <img src={item.image} className="img-fluid" alt="Product Image" />
                      </div>
                      <div className="col-md-9">
                        <h4 className="card-title">{item.title}</h4>
                        <p className="card-text">Price: ${item.price}</p>
                        <p className="card-text">Category: {item.category}</p>
                        <p className="card-text">Rating: {item.rating.rate} ({item.rating.count} reviews)</p>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
              <div className="text-right mt-3">
                <p className="font-weight-bold">Subtotal: ${order.subTotal}</p>
                <p className="font-weight-bold">Tax: ${order.tax}</p>
                <p className="font-weight-bold">Shipping: ${order.shipping}</p>
                <p className="font-weight-bold">Order Total: ${order.orderTotal}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderList;
