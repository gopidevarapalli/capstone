import React, { useEffect, useState } from 'react';
import OrderList from './OrderList'; // assuming OrderList.js is in the same directory
import axios from 'axios';
import { apiURL } from '../Config';
import { useSelector } from 'react-redux';
import Header from '../Header';
import Footer from '../Footer';

const Orders = () => {
  const login = useSelector(state => state.login);
  const [ordersData, setOrdersData] = useState([]);

  useEffect(()=>{
    axios.get(`${apiURL}/orders?userId=${login?.data?.id}`)
    .then(res=>{
        setOrdersData(res.data);
    })
  },[])

  return (
    <div>
        <Header />
      {ordersData.map(order => (
        <OrderList key={order.id} order={order} />
      ))}
      <Footer />
    </div>
  );
};

export default Orders;
