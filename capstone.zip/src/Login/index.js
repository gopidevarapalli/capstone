import axios from "axios";
import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { loginAction } from "../redux/actions";
import { apiURL } from "../Config";

const Login = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleLogin = () => {
   

    axios.get(`${apiURL}/users?email=${username}&password=${password}`)
    .then((res)=>{
        if(res?.data?.length) {
            setError("");
            dispatch(loginAction(res?.data?.[0]))
            localStorage.setItem('user', JSON.stringify(res?.data?.[0]));
            navigate(`/home`);
        }else {
            setError("Invalid username or password");
        }
    })
    .catch(e=>{
        setError(e.message);
    })

  };

  useEffect(()=>{
    const loggedInData = localStorage.getItem('user');
    if(loggedInData) {
        dispatch(loginAction(JSON.parse(loggedInData)))
        navigate(`/home`);
    }
  }, [])

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card">
            <div className="card-header">Login</div>
            <div className="card-body">
              {error && (
                <div className="alert alert-danger" role="alert">
                  {error}
                </div>
              )}
              <div className="mb-3">
                <label htmlFor="username" className="form-label">
                  Username
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                />
              </div>
              <div className="mb-3">
                <label htmlFor="password" className="form-label">
                  Password
                </label>
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <button className="btn btn-primary" onClick={handleLogin}>
                Login
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
