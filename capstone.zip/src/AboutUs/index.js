import React from "react";
import Header from "../Header";
import Footer from "../Footer";

const AboutUs = () => {

    return (<div className="d-flex flex-column min-vh-100"><Header />
        <div>
            <h1 className="text text-center text-warning">About US</h1>
            <hr />

        </div>
        <Footer />
        </div>
    )
}

export default AboutUs;