import axios from "axios";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { updateCart } from "../redux/actions";
import { useDispatch, useSelector } from "react-redux";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar } from "@fortawesome/free-solid-svg-icons";
import Header from "../Header";
import Footer from "../Footer";

const ProductDetail = () => {

    const products = useSelector(state => state.products);
    const cart = useSelector(state => state.cart);
    const [product, setProduct] =  useState(null);
    const params = useParams();
    const dispatch = useDispatch();

    useEffect(() => {
      const findProduct = products?.data?.find((item)=> item.id === params?.id);
      console.log(findProduct)
      if(findProduct) {
        setProduct(findProduct)
      } else {
        axios.get(`http://localhost:3001/products?id=${params?.id}`)
        .then((res) => setProduct(...res.data))
        .catch((error) => console.error("Error fetching product:", error));
      }

    }, [params?.id]);

    const addToCart = (product) => {
      console.log('product=', product);
      dispatch(updateCart([...cart.data, product]));
    }
    const isItemAdded = (id) => cart?.data?.find(item => item.id === id);
    return (<div className="d-flex flex-column min-vh-100"><Header />
      <div className="container mt-4">
        {product && (<>
          <div className="row">
            <div className="col-md-4">
              <img src={product?.image} alt={product?.title} className="img-fluid" />
            </div>
            <div className="col-md-8">
              <h2>{product?.title}</h2>
              <p className="lead">{product?.description}</p>
              <div className="mb-2">
                    {[...Array(5)].map((_, index) => (
                      <FontAwesomeIcon
                        key={index}
                        icon={faStar}
                        className={ (index) <= product?.rating?.rate? "mr-2 text-warning" : "mr-2"}
                        style={{ cursor: 'pointer' }}
                      />
                    ))}
                    <span style={{fontSize: 12}}>{product?.rating?.rate}</span>
              </div>
              <p><strong>Category:</strong> {product?.category}</p>
              <p><strong>Price:</strong> ${product?.price}</p>
              <div className="d-grid gap-2 d-md-flex justify-content-md-start">
                <button className="btn btn-primary me-md-2" type="button" disabled={isItemAdded(product?.id)} onClick={() =>addToCart(product)}>
                  {isItemAdded(product?.id)?<>
                  <span>Added</span>
                  </>: 'Add to Cart'}
                  
                  </button>
                <button className="btn btn-outline-secondary" type="button">Add to Wishlist</button>
              </div>
              {isItemAdded(product?.id) && <div className="alert alert-success mt-5" role="alert">
                    Item added to cart <span className="fas fa-check-circle checked text-success"></span>
                </div>}
            </div>
          </div>
          </>
        )}
      </div>
      <Footer />
      </div>
    );
}

export default ProductDetail;
