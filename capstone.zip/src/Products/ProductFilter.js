import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faStar } from '@fortawesome/free-solid-svg-icons';
import { useDispatch, useSelector } from 'react-redux';
import { updateProductFilter } from '../redux/actions';

const ProductFilter = () => {
  const products = useSelector(state => state.products);
  const [selectedSort, setSelectedSort] = useState(products?.filter?.enable ? products?.filter?.orderBy : '');
  const dispatch = useDispatch();

  const handleSortSelection = (e) => {
    const selectedValue = e.target.value;
    dispatch(updateProductFilter({
      ...products?.filter,
      enable: true,
      orderBy: selectedValue,
    }));
    setSelectedSort(selectedValue);
  };

  const handleRatingSelection = (rating) => {
    dispatch(updateProductFilter({
      ...products?.filter,
      enable: true,
      rating
    }));
  };

  const clearFilter = () => {
    // dispatch(clearProductFilter());
    setSelectedSort('');
    dispatch(updateProductFilter({
        enable: false,
        rating:0,
        orderBy: ''
      }));
  };

  return (
    <div className="container mt-3">
      <h4>Filter Products</h4>
      <hr />
      <div>
        <h5>Sort By:</h5>
        <div className="form-check">
          <input
            className="form-check-input"
            type="radio"
            name="sort"
            id="ascending"
            value="ascending"
            checked={selectedSort === 'ascending'}
            onChange={handleSortSelection}
          />
          <label className="form-check-label" htmlFor="ascending">
            Ascending Order
          </label>
        </div>
        <div className="form-check">
          <input
            className="form-check-input"
            type="radio"
            name="sort"
            id="descending"
            value="descending"
            checked={selectedSort === 'descending'}
            onChange={handleSortSelection}
          />
          <label className="form-check-label" htmlFor="descending">
            Descending Order
          </label>
        </div>
      </div>
      <hr />
      <div>
        <h5>Filter By Rating:</h5>
        <div>
          {[...Array(5)].map((_, index) => (
            <FontAwesomeIcon
              key={index}
              icon={faStar}
              className={products?.filter?.enable && products?.filter?.rating > 0 && index < products?.filter?.rating ? "mr-2 text-warning" : "mr-2"}
              style={{ cursor: 'pointer' }}
              onClick={() => handleRatingSelection(index + 1)}
            />
          ))}
        </div>
      </div>
      <hr />
      <button className="btn btn-outline-secondary" onClick={clearFilter}>Clear Filter</button>
    </div>
  );
};

export default ProductFilter;
