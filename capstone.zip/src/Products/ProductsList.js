import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { updateCart } from "../redux/actions";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faRupeeSign, faStar } from '@fortawesome/free-solid-svg-icons';

export const ProductsList = ({products}) => {
    const cart = useSelector(state => state.cart);
    console.log('cart=',JSON.stringify(cart.data))
    const dispatch = useDispatch();
    const addToCart = (product) => {
      dispatch(updateCart([...cart.data, product]));
    }
    const isItemAdded = (id) => cart?.data?.find(item => item.id === id);
    return (
      <div className="row">
      {products.map(product => (
        <div key={product.id} className="col-md-3">
          <div className="card mb-4 shadow-sm">
            <div className="row rowHeight">
              <div className="col-md-2"></div>
              <div className="col-md-8">
                <img src={product.image} alt={product.title} className="img" width="100%" height={200} />

              </div>
              <div className="col-md-2"></div>
            </div>
            <div className="card-body">
              <strong className="card-title">{product.title.substr(0,21)}</strong>
              <p className="small mb-0">{product.description.substr(0,12)}....<Link to={`/products/${product.id}`} className="text-decoration-none">show more</Link></p>
              <div className="mb-2">
                    {[...Array(5)].map((_, index) => (
                      <FontAwesomeIcon
                        key={index}
                        icon={faStar}
                        className={ index <= product?.rating?.rate? "mr-2 text-warning" : "mr-2"}
                        style={{ cursor: 'pointer' }}
                      />
                    ))}
                    <span style={{fontSize: 12}}>{product?.rating?.rate}</span>
                  </div>
              <div className="d-flex justify-content-between align-items-center">
                <div className="btn-group">
                  <Link type="button" className="btn btn-sm btn-outline-secondary" to={`/products/${product.id}`}>View</Link>
                  <button type="button" className="btn btn-sm btn-outline-secondary" onClick={()=> addToCart(product)} disabled={isItemAdded(product?.id)}>
                    {
                    isItemAdded(product?.id)?
                    <span>Added  <span className="fas fa-check-circle checked text-success"></span></span>: 'Add to Cart'}</button>
                </div>
                <small className="text">Rs.{product.price}</small>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
    )
}