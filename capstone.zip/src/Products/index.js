import React, { useEffect, useState } from "react";
import './styles.css';
import { ProductsList } from "./ProductsList";
import axios from "axios";
import { Outlet } from "react-router-dom";
import { useSelector } from "react-redux";
import ProductFilter from "./ProductFilter";

const Products = () => {
    const products = useSelector((state) => state.products);
    const { data: allProducts, loading, searchTerm, filter: {
      enable,
      orderBy,
      rating
    } } = products;

    let filteredProducts = [...allProducts];



    const sortProducts = (items) => {
      filteredProducts.sort((a, b) => {
        if (orderBy === 'ascending') {
            return a.price - b.price;
        } else if (orderBy === 'descending') {
            return b.price - a.price;
        } else {
            return a.price - b.price;
        }
      });
    return filteredProducts;
} 

      if(enable) {
        filteredProducts = orderBy?  sortProducts(filteredProducts) : filteredProducts
        if(rating) {
          console.log(rating)
          filteredProducts = filteredProducts?.filter(item => item?.rating?.rate >= rating)
        }
      } else {
        filteredProducts = [...allProducts]
      }

      if (searchTerm && searchTerm.trim() !== "") {
        filteredProducts = filteredProducts?.filter(item =>
            item?.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
            item?.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
            item?.description.toLowerCase().includes(searchTerm.toLowerCase()) 
        );
    }
    


    console.log(JSON.stringify(filteredProducts))
    return (
        <div className="container-fluid">
            {/* <h1 className="text text-left text-warning">Products</h1>
            <hr /> */}
            <div className="row">
            {/* <div className="col-md-1"></div> */}
            <div className="col-md-3">
            <ProductFilter /> 
            </div>
            <div className="col-md-8">
           {searchTerm?.length ? <h3>Product search "{searchTerm}"</h3> : null}
            {filteredProducts.length === 0 && (
                <div className="alert alert-info" role="alert">
                    No products found.
                </div>
            )}
            {loading && <p>Loading....</p>}
            <ProductsList products={filteredProducts || []} />
            </div>
            </div>
        </div>
    );
}

export default Products;
