
import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import React, { Suspense } from 'react';
import { Route, Router, Routes } from 'react-router-dom';
import UserDetailsEdit from './Users/UserDetailsEdit';
import Login from './Login';
import Orders from './Orders';
const Home = React.lazy(() => import('./Home'));
const Header = React.lazy(() => import('./Header'));
const Footer = React.lazy(() => import('./Footer'));
const Users = React.lazy(() => import('./Users'));
const UserDetails = React.lazy(() => import('./Users/UserDetails'));
const Products = React.lazy(() => import('./Products'));
const ProductDetail  = React.lazy(() => import('./Products/ProductDetail'));
const Cart = React.lazy(() => import('./Cart'));
const AboutUs = React.lazy(() => import('./AboutUs'));

function App() {
  return (
      <>
          <Routes>
            <Route path="/" element={<Suspense fallback={<div> Login Loading...</div>}><Login /></Suspense>} />
            <Route path="/home" element={<Suspense fallback={<div> Homepage Loading...</div>}><Home /></Suspense>} />
            <Route path="/products" element={<Suspense fallback={<div>Loading...</div>}><Products /></Suspense>} />
              <Route path="/users" element={<Suspense fallback={<div>Loading...</div>}><Users /></Suspense>}>
                <Route path='edit/:id' element={<Suspense fallback={<div>Loading...</div>}><UserDetailsEdit /></Suspense>} />
                <Route path='add' element={<Suspense fallback={<div>Loading...</div>}><UserDetailsEdit /></Suspense>} />
                <Route path=':id' element={<Suspense fallback={<div>Loading...</div>}><UserDetails /></Suspense>} />
              </Route>
            <Route path="/products/:id" element={<Suspense fallback={<div>Loading...</div>}><ProductDetail /></Suspense>} />
            <Route path="/cart" element={<Suspense fallback={<div>Loading...</div>}><Cart /></Suspense>} />
            <Route path="/orders" element={<Suspense fallback={<div>Loading...</div>}><Orders /></Suspense>} />
            <Route path="/about-us" element={<Suspense fallback={<div>Loading...</div>}><AboutUs /></Suspense>} />
          </Routes>
      </>
  );
}

export default App;
