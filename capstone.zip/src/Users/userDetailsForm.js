import React, { useEffect } from 'react';
import axios from 'axios';
import { useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import { apiURL } from '../Config';

const UserDetailsForm = ({ userData }) => {
  const navigate = useNavigate();
  const { register, handleSubmit, setValue, formState: { errors } } = useForm();
  const roles = ["Trainee", "Junior Developer", "Developer", "Technology Lead", "Manager", "Group Manager"];
  const onSubmit = (data) => {
    if (data?.id) {
      axios.put(`${apiURL}/users/${data?.id}`, data)
        .then(res => {
          console.log(res.data);
          navigate(`/users/${data?.id}`);
        }).catch(e => {
          console.log('error', e);
        });
    } else {
      console.log('payload=', data);
      axios.post(`${apiURL}/users/`, data)
        .then(res => {
          console.log(res.data);
          navigate(`/users/${res.data?.id}`);
        }).catch(e => {
          console.log('error', e);
        });
    }
  };

  useEffect(() => {
    if (userData) {
      Object.entries(userData).forEach(([key, value]) => {
        setValue(key, value);
      });
    }
  }, [userData, setValue]);

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="mb-3">
        <label htmlFor="name" className="form-label">Name</label>
        <input type="text" className="form-control" id="name" {...register("name", {
          required: "Name is required",
          pattern: {
            value: /^[A-Za-z0-9]+(?:[ _-][A-Za-z0-9]+)*$/,
            message: "Invalid Name format"
          }
        })} />
        {errors.name && <p className='text text-danger'>{errors.name.message}</p>}
      </div>
      <div className="mb-3">
        <label htmlFor="email" className="form-label">Email</label>
        <input type="email" className="form-control" id="email" {...register("email", {
          required: "Email is required",
          pattern: {
            value: /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
            message: "Invalid email address"
          }
        })} />
        {errors.email && <p className='text text-danger'>{errors.email.message}</p>}
      </div>
      <div className="mb-3">
        <label htmlFor="sapId" className="form-label">SAP ID</label>
        <input type="text" className="form-control" id="sapId" {...register("sapId", {
          required: "SAP ID is required",
          pattern: {
            value: /^\d{8}$/,
            message: "Invalid SAP, must be 8 digits"
          }
        })} />
        {errors.sapId && <p className='text text-danger'>{errors.sapId.message}</p>}
      </div>
      <div className="mb-3">
        <label htmlFor="role" className="form-label">Role</label>
        <select id="role" className="form-select" {...register("role", { required: "Role is required" })}>
          <option value="">Select Role</option>
          {roles.map((role, index) => (
            <option key={index} value={role}>{role}</option>
          ))}
        </select>
        {errors.role && <p className='text text-danger'>{errors.role.message}</p>}
      </div>
      <div className="mb-3">
        <label htmlFor="phone" className="form-label">Phone</label>
        <input type="text" className="form-control" id="phone" {...register("phone", {
          required: "Phone is required",
          pattern: {
            value: /^[0-9]{10}$/,
            message: "Invalid phone number, must be 10 digits"
          }
        })} />
        {errors.phone && <p className='text text-danger'>{errors.phone.message}</p>}
      </div>
      <div className="mb-3">
        <label htmlFor="Client" className="form-label">Client</label>
        <input type="text" className="form-control" id="Client" {...register("Client")} />
      </div>
      <div className="mb-3">
        <label htmlFor="password" className="form-label">Password</label>
        <input type="password" className="form-control" id="password" {...register("password", {
          required: "Password is required",
          minLength: {
            value: 6,
            message: "Password must have at least 6 characters"
          }
        })} />
        {errors.password && <p className='text text-danger'>{errors.password.message}</p>}
      </div>
      <div className="mb-3">
        <label htmlFor="street" className="form-label">Street</label>
        <input type="text" className="form-control" id="street" {...register("address.street")} />
      </div>
      <div className="mb-3">
        <label htmlFor="suite" className="form-label">Suite</label>
        <input type="text" className="form-control" id="suite" {...register("address.suite")} />
      </div>
      <div className="mb-3">
        <label htmlFor="city" className="form-label">City</label>
        <input type="text" className="form-control" id="city" {...register("address.city")} />
      </div>
      <div className="mb-3">
        <label htmlFor="zipcode" className="form-label">Zipcode</label>
        <input type="text" className="form-control" id="zipcode" {...register("address.zipcode")} />
      </div>
      <button type="submit" className="btn btn-primary">Submit</button>
    </form>
  );
};

export default UserDetailsForm;
