import axios from "axios";
import React from "react";
import { Link } from "react-router-dom";
import { apiURL } from "../Config";

export const UserList = ({employees}) => {

  const onDelete = (id, username) => {
    const conf = window.confirm('Are you sure Do you want to delete?');
    if(conf) {
      axios.delete(`${apiURL}/users/${id}`);
    }
  }
    return(<>
    <Link className="btn btn-primary" to={'/users/add'}>Add User +</Link>
        <table className="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      {/* <th scope="col">Username</th> */}
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Phone</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
        {employees.map((employee, index) => (
            <tr key={index}>
            <th scope="row">{employee?.id}</th>
            {/* <td>{employee?.username}</td> */}
            <td>{employee?.name}</td>
            <td>{employee?.email}</td>
            <td>{employee?.phone}</td>
            <td>
                <div className="d-flex">
                     <td> 
                     <Link className="btn btn-primary me-2" to={`/users/${employee?.id}`}>
                        View
                      </Link>
                    </td>
                    <td>
                    <Link className="btn btn-warning me-2" to={`/users/edit/${employee?.id}`}>
                        Edit
                      </Link>
                    </td>
                    <td>
                        <button className="btn btn-danger" onClick={()=> onDelete(employee?.id, employee?.username)}>Delete</button>
                    </td>
                </div>
            </td>
            </tr>
        ))}
   </tbody>
   </table>
   </>

    )
}