
import React, { useEffect, useState } from "react";
import { UserList } from "./UserList";
import axios from "axios";
import { Outlet } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { fetchUsersRequest, fetchUsersSuccess } from "../redux/actions";
import { apiURL } from "../Config";
import Header from "../Header";
import Footer from "../Footer";
const Users = () =>{
    const employees = useSelector(state => state.users);
    const dispatch = useDispatch();

    useEffect(()=>{
      if(!employees?.isDataLoaded) {
        dispatch(fetchUsersRequest())
        axios.get(`${apiURL}/users`)
        .then((res)=>{
            dispatch(fetchUsersSuccess(res.data));
        });
    }
    }, [])

    return(<div className="d-flex flex-column min-vh-100"><Header />
    <div className="container-fluid">
        <div className="row"> 
            <div className="col-md-1"></div>
            <div className="col-md-11">
              <h1 className="text text-left text-warning mt-20">Users</h1>
            </div>
        </div>
        <hr />
        <div className="row">
            <div className="col-md-1"></div>
            <div className="col-md-5">
              <UserList employees={employees?.data} />
            </div>
            <div className="col-md-1"></div>
            <div className="col-md-5"> 
               <Outlet />
            </div>
        </div>
    </div>
    <Footer />
    </div>)
}

export default Users;