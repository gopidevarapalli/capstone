import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import { apiURL } from "../Config";

const UserDetails = () => {
  const [user, setUser] = useState(null);
  const params = useParams();

  useEffect(() => {
    axios
      .get(`${apiURL}/users?id=${params?.id}`)
      .then((res) => setUser(...res.data))
      .catch((error) => console.error("Error fetching user:", error));
  }, [params?.id]);
console.log('user=', user);
  return (
    <div className="container">
      {user && (
        <div>
          <h2 className="text text-warning">User Details</h2>
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">#{user?.id} {user?.name}</h5>
              <p className="card-text">
              <strong>SAP ID:</strong> {user?.sapId}
                <br />
                <strong>Role:</strong> {user?.role}
                <br />
                <strong>Email:</strong> {user?.email}
                <br />
                <strong>Phone:</strong> {user?.phone}
                <br />
                <strong>Website:</strong>{" "}
                <a href={`http://${user?.website}`} target="_blank">
                  {user?.website}
                </a>
              </p>
            </div>
          </div>
          <div className="card mt-3">
            <div className="card-body">
              <h5 className="card-title">Address</h5>
              <p className="card-text">
                {user.address.street}, {user.address.suite}, {user.address.city}, {user.address.zipcode}
              </p>
            </div>
          </div>

        </div>
      )}
    </div>
  );
};

export default UserDetails;
