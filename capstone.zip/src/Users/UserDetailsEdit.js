import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import UserDetailsForm from "./userDetailsForm";
import { apiURL } from "../Config";

const UserDetailsEdit = () => {
  const [user, setUser] = useState(null);
  const params = useParams();

  useEffect(() => {
    if(params?.id) {
      axios
      .get(`${apiURL}/users?id=${params?.id}`)
      .then((res) => setUser(...res.data))
      .catch((error) => console.error("Error fetching user:", error));
    }

  }, [params?.id]);

  return (
    <div className="container">
        <UserDetailsForm userData={user} />
    </div>
  );
};

export default UserDetailsEdit;
