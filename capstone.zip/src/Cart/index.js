import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { updateCart } from "../redux/actions";
import Header from "../Header";
import Footer from "../Footer";
import axios from "axios";
import { apiURL } from "../Config";
import { useNavigate } from "react-router-dom";

const Cart = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const login = useSelector(state => state.login);
    const cart = useSelector(state => state.cart);
    const cartItems = cart?.data || [];
    const subTotal = cartItems.reduce((total, item) => total + item.price, 0).toFixed(2);
    const tax = 0;
    const shipping = 0;
    const orderTotal = subTotal + tax + shipping;

    const removeItem = (index) => {
       let items =  [...cartItems]
       console.log('before remove items=',items)
       items.splice(index,1);
       console.log('after remove items=', items);
       dispatch(updateCart(items))
    }
    const renderRatingStars = (rating) => {
        console.log(rating)
        const stars = [];
        for (let i = 0; i < 5; i++) {
            if (i < rating) {
                stars.push(<span key={i} className="fa fa-star checked text-warning"></span>);
            } else {
                stars.push(<span key={i} className="fa fa-star"></span>);
            }
        }
        return stars;
    };

    const placeOrder = () => {
        const payload = {
            userId: login?.data?.id,
            selectedItems: cart?.data,
            subTotal,
            tax,
            shipping,
            orderTotal,
            orderDate: new Date()
        }
        axios.post(`${apiURL}/orders`, payload)
        .then((res)=>{
            alert('Order Placed successfully!');
            dispatch(updateCart([]));
            navigate('/home');
        })
    }

    return (<div className="d-flex flex-column min-vh-100"><Header />
        <div className="container mt-5">
            <h1 className="mb-4">Shopping Cart</h1>
            {cartItems.length === 0 && (
                <div className="alert alert-info" role="alert">
                    No items in the cart.
                </div>
            )}
            <div className="cart-items">
                {cartItems.map((item, index) => (
                    <div className="card mb-4" key={item.id} style={{ width: "100%" }}>
                        <div className="card-body d-flex align-items-start">
                            <img src={item.image} className="card-img-top" alt={item.title} style={{ maxWidth: "200px", maxHeight: "200px", objectFit: "cover", padding: 20 }} />
                            <div className="ml-4">
                                <h5 className="card-title mb-1">{item.title}</h5>
                                <p className="card-text mb-2" style={{ fontSize: "0.9rem" }}>{item.description}</p>
                                <p className="card-text mb-2">Price: Rs.{item.price}</p>
                                <p className="card-text mb-2">Rating: {renderRatingStars(item.rating.rate)}</p>
                                <button className="btn btn-danger" onClick={()=> removeItem(index)}>Remove</button>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
            {cartItems.length > 0 && (
                <div className="row mt-4">
                    <div className="col-md-8">
                        <div className="card">
                            <div className="card-body">
                                <h5 className="card-title">Total</h5>
                                <p className="card-text">Subtotal: Rs.{subTotal}</p>
                                <p className="card-text">Tax: Rs.{tax}</p>
                                <p className="card-text">Subtotal: Rs.{shipping}</p>
                                <p className="card-text">Total: Rs.{orderTotal}</p>
                                <button className="btn btn-primary" onClick={()=> placeOrder()}>Place Order</button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
        <Footer />
        </div>
    )
}

export default Cart;
